<?php 
//ip de la pc servidor base de datos
define("DB_HOST", "localhost");

// nombre de la base de datos
define("DB_NAME", "dbmitienda");


//nombre de usuario de base de datos
define("DB_USERNAME", "root");

//conraseña del usuario de base de datos
define("DB_PASSWORD", "");

//codificacion de caracteres
define("DB_ENCODE", "utf8");

//nombre del proyecto
define("PRO_NOMBRE", "ITVentas");
 
 ?>